package upf.edu.filter;

public class FilterException extends Exception {

  public FilterException(Throwable e){};

}
